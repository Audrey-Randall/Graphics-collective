To run: No command line arguments are needed.

To toggle cube rotation, press 1. Arrow keys move, and page up and page down zoom, while in an orthographic view.
Press p to swap between orthographic and perspective projections. This works very poorly even though I translate my cartesian coordinates back into spherical.
w, a, s, and d work like video game controls: w steps forward, s backward, a and d rotate you. These controls only work in perspective.

I spent about 9 hours on this project.
